///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  raphael dedes
// 09/20/2026
// 09/27/2026
// 10/04/2026
// 10/11/2026
// 10/18/2026
// module 3 milestone
// module 4 milestone	
// module 5 milestone
// module 6 milestone
// module 7 final project!!
///////////////////////////////////////////////////////////////////////////////

//including these for custom mesh
#include <vector>
#include <cmath>
#include <glm/gtc/matrix_transform.hpp>
#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(bFound);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

//SetShaderLights();
//configures overhead light

void SceneManager::SetShaderLights()
{
	//main overhead light 1
	m_pShaderManager->setVec3Value(
		"lightSources[0].position", -6.0f, 9.0f, 0.0f);

	m_pShaderManager->setVec3Value(
		"lightSources[0].direction", 0.0f, -1.0f, 0.0f);
	m_pShaderManager->setIntValue(
		"lightSources[0].isDirectional", 0);

	m_pShaderManager->setVec3Value(
		"lightSources[0].ambientColor", 0.25f, 0.25f, 0.25f);
	m_pShaderManager->setVec3Value(
		"lightSources[0].diffuseColor", 1.0f, 1.0f, 0.95f);
	m_pShaderManager->setVec3Value(
		"lightSources[0].specularColor", 1.0f, 1.0f, 1.0f);
	m_pShaderManager->setFloatValue(
		"lightSources[0].focalStrength", 32.0f);
	m_pShaderManager->setFloatValue(
		"lightSources[0].specularIntensity", 0.5f);

	//blue point light
	m_pShaderManager->setVec3Value(
		"lightSources[1].position", 2.0f, 5.0f, 3.0f);

	m_pShaderManager->setVec3Value(
		"lightSources[1].direction", 0.0f, -1.0f, 0.0f);
	m_pShaderManager->setIntValue(
		"lightSources[1].isDirectional", 1);


	m_pShaderManager->setVec3Value(
		"lightSources[1].ambientColor", 0.0f, 0.03f, 0.08f);

	m_pShaderManager->setVec3Value(
		"lightSources[1].diffuseColor", 0.15f, 0.3f, 0.8f);

	m_pShaderManager->setVec3Value(
		"lightSources[1].specularColor", 0.3f, 0.4f, 1.0f);

	m_pShaderManager->setFloatValue(
		"lightSources[1].focalStrength", 32.0f);

	m_pShaderManager->setFloatValue(
		"lightSources[1].specularIntensity", 0.3f);

	//keeps remaining lights inactive
	for (int i = 2; i < 4; i++)



	{
		m_pShaderManager->setVec3Value(
			"lightSources[" + std::to_string(i) + "].ambientColor",
			0.0f, 0.0f, 0.0f);
		m_pShaderManager->setVec3Value(
			"lightSources[" + std::to_string(i) + "].diffuseColor",
			0.0f, 0.0f, 0.0f);
		m_pShaderManager->setVec3Value(
			"lightSources[" + std::to_string(i) + "].specularColor",
			0.0f, 0.0f, 0.0f);
		m_pShaderManager->setFloatValue(
			"lightSources[" + std::to_string(i) + "].specularIntensity",
			0.0f);
	}
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	//adding this for bottle
	m_basicMeshes->LoadTorusMesh();

	//custom shape for tray
	m_basicMeshes->LoadHollowCylinderMesh();

	//spatula
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadPrismMesh();

	//basic shapes for the capsules	
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadSphereMesh();

	//plane
	m_basicMeshes->LoadPlaneMesh();

	//textures
	CreateGLTexture("textures/wood-texture.jpg", "wood-texture");
	CreateGLTexture("textures/shiny-silver.jpg", "shiny-silver");
	CreateGLTexture("textures/circular-brushed-gold-texture.jpg", "gold");
	CreateGLTexture("textures/pod-texture3.jpg", "pod-texture");
	//CreateGLTexture("textures/fluoxetine_label.jpg", "fluoxetine");

	BindGLTextures();
}

//**********************************



//adding in pill bottle + cap

void SceneManager::DrawPillBottle()
{
	//pill bottle base
	SetTransformations(
		glm::vec3(1.9f, 0.5f, 1.9f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(-6.0f, -1.3f, -4.0f));

	SetShaderColor(0.95f, 0.95f, 0.93f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	//pill bottle body back
	SetTransformations(
		glm::vec3(4.0f, 4.0f, 3.3f),
		90.0f, 0.0f, 0.0f,
		glm::vec3(-6.0f, 0.35f, -4.0f));

	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	m_basicMeshes->DrawHollowCylinderMesh();

	//pill bottle body front
	SetTransformations(
		glm::vec3(4.0f, 4.0f, 3.3f),
		90.0f, 0.0f, 180.0f,
		glm::vec3(-6.0f, 0.35f, -4.0f));

	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	//SetShaderTexture("fluoxetine");
	//SetTextureUVScale(0.25f, 1.0f);
	m_basicMeshes->DrawHollowCylinderMesh();

	//round neck
	SetTransformations(
		glm::vec3(1.68f, 1.68f, 3.0f),
		90.0f, 0.0f, 0.0f,
		glm::vec3(-6.0f, 2.0f, -4.0f));

	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	m_basicMeshes->DrawTorusMesh();


	//narrow neck
	// 
	//left
	SetTransformations(
		glm::vec3(3.0f, 3.0f, 2.0f),
		90.0f, 0.0f, -90.0f,
		glm::vec3(-6.0f, 2.5f, -4.0f));

	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	m_basicMeshes->DrawHollowCylinderMesh();

	//right
	SetTransformations(
		glm::vec3(3.0f, 3.0f, 2.0f),
		90.0f, 0.0f, 90.0f,
		glm::vec3(-6.0f, 2.5f, -4.0f));

	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	m_basicMeshes->DrawHollowCylinderMesh();

	

	//small rim around the neck
	
	//left
	SetTransformations(
		glm::vec3(3.2f, 3.5f, 0.08f),
		90.0f, 0.0f, -90.0f,
		glm::vec3(-5.8f, 2.9f, -4.0f));

	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	m_basicMeshes->DrawHollowCylinderMesh();

	//right
	SetTransformations(
		glm::vec3(3.2f, 3.5f, 0.08f),
		90.0f, 0.0f, 90.0f,
		glm::vec3(-6.2f, 3.2f, -4.0f));

	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	m_basicMeshes->DrawHollowCylinderMesh();


	//pill bottle cap

	//base
	SetTransformations(
		glm::vec3(1.7f, 0.2f, 1.7f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(-1.0f, -1.3f, -4.0f));

	SetShaderColor(0.95f, 0.95f, 0.93f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	//cap back
	SetTransformations(
		glm::vec3(3.7f, 3.7f, 1.3f),
		90.0f, 0.0f, 0.0f,
		glm::vec3(-1.0f, -0.68f, -4.0f));

	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	m_basicMeshes->DrawHollowCylinderMesh();

	//cap front
	SetTransformations(
		glm::vec3(3.7f, 3.7f, 1.3f),
		90.0f, 0.0f, 180.0f,
		glm::vec3(-1.0f, -0.68f, -4.0f));

	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	m_basicMeshes->DrawHollowCylinderMesh();

	

}

// adding in spatula object

void SceneManager::DrawSpatula(glm::vec3 position)
{
	//spatula blade
	glm::vec3 scaleXYZ = glm::vec3(1.3f, 0.08f, 10.0f);
	glm::vec3 positionXYZ = glm::vec3(2.5f, 0.15f, 0.0f) + position;

	SetTransformations(
		scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	SetShaderTexture("shiny-silver");
	SetTextureUVScale(1.0f, 1.0f);

	//make the spatula blade shiny
	m_pShaderManager->setVec3Value(
		"material.specularColor", 1.0f, 1.0f, 1.0f);
	m_pShaderManager->setFloatValue(
		"material.shininess", 64.0f);

	m_basicMeshes->DrawBoxMesh();


	//spatula blade rounded end
	scaleXYZ = glm::vec3(0.65f, 0.08f, 0.9f);
	positionXYZ = glm::vec3(2.5f, 0.11f, -5.0f) + position;

	SetTransformations(
		scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	SetShaderTexture("shiny-silver");
	SetTextureUVScale(1.0f, 1.0f);

	//make the rounded end shiny
	m_pShaderManager->setVec3Value(
		"material.specularColor", 1.0f, 1.0f, 1.0f);
	m_pShaderManager->setFloatValue(
		"material.shininess", 64.0f);

	m_basicMeshes->DrawCylinderMesh();


	//spatula handle
	scaleXYZ = glm::vec3(1.5f, 0.48f, 8.0f);
	positionXYZ = glm::vec3(2.5f, 0.15f, 8.0f) + position;

	SetTransformations(
		scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	SetShaderTexture("wood-texture");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawBoxMesh();


	//spatula handle point
	scaleXYZ = glm::vec3(1.5f, 0.48f, 1.0f);
	positionXYZ = glm::vec3(2.5f, 0.15f, 12.5f) + position;

	SetTransformations(
		scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	SetShaderTexture("wood-texture");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawPrismMesh();


	//spatula gold circle 1
	scaleXYZ = glm::vec3(0.3f, 0.50f, 0.3f);
	positionXYZ = glm::vec3(2.5f, -0.1f, 5.0f) + position;

	SetTransformations(
		scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	SetShaderTexture("gold");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawCylinderMesh();


	//spatula gold circle 2
	scaleXYZ = glm::vec3(0.3f, 0.50f, 0.3f);
	positionXYZ = glm::vec3(2.5f, -0.1f, 7.0f) + position;

	SetTransformations(
		scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	SetShaderTexture("gold");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawCylinderMesh();
}

//adding in tray object
void SceneManager::DrawTray()
{
	m_pShaderManager->setVec3Value(
		"material.specularColor", 0.08f, 0.08f, 0.08f);
	m_pShaderManager->setFloatValue(
		"material.shininess", 8.0f);
	
	//base
	SetTransformations(
		glm::vec3(12.0f, 0.2f, 14.0f),
		0.0f, 90.0f, 0.0f,
		glm::vec3(-3.0f, 0.0f, 6.0f));

	SetShaderColor(0.38f, 0.40f, 0.42f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	//back

	SetTransformations(
		glm::vec3(0.2f, 0.5f, 13.8f),
		0.0f, 90.0f, 0.0f,
		glm::vec3(-3.2f, 0.3f, 0.1f));

	SetShaderColor(0.38f, 0.40f, 0.42f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	//front
	SetTransformations(
		glm::vec3(0.2f, 0.2f, 14.0f),
		0.0f, 90.0f, 0.0f,
		glm::vec3(-3.0f, 0.1f, 11.9f));

	SetShaderColor(0.38f, 0.40f, 0.42f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	//left pill catcher
	SetTransformations(
		//xyz , widens mouth, increases depth , length
		glm::vec3(3.0f, 2.5f, 12.0f),
		//rotations xyz
		0.0f, 0.0f, 0.0f,
		//xyz moves right+/left-, moves up+/down-, moves forward+/backward-
		glm::vec3(-11.26f, 0.0f, 6.0f));

	SetShaderColor(0.38f, 0.40f, 0.42f, 1.0f);
	
	m_basicMeshes->DrawHollowCylinderMesh();

	//right pill catcher
	SetTransformations(
		glm::vec3(3.0f, 2.5f, 12.0f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(5.25f, 0.0f, 6.0f));

	//SetShaderColor(1.38f, 0.40f, 1.42f, 1.0f); //testing color (bright pink)
	SetShaderColor(0.38f, 0.40f, 0.42f, 1.0f);
	m_basicMeshes->DrawHollowCylinderMesh();


	//back face plate for left pill catcher
	SetTransformations(
		glm::vec3(1.4f, 0.2f, 1.2f),
		90.0f, 0.0f, 0.0f,
		glm::vec3(-11.26f, 0.0f, 0.0f));

	SetShaderColor(0.38f, 0.40f, 0.42f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	//back face plate for right pill catcher
	SetTransformations(
		glm::vec3(1.4f, 0.2f, 1.2f),
		90.0f, 0.0f, 0.0f,
		glm::vec3(5.25f, 0.0f, 11.80f));

	SetShaderColor(0.38f, 0.40f, 0.42f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();


	//left plastic pill catcher cover
	SetTransformations(
		
		glm::vec3(3.0f, 2.5f, 12.0f),
		
		0.0f, 0.0f, 180.0f,
		glm::vec3(-11.26f, 0.0f, 6.0f));

	SetShaderColor(0.95f, 0.97f, 1.0f, 0.3f);
	m_basicMeshes->DrawHollowCylinderMesh();

	//right plastic pill catcher cover
	SetTransformations(

		glm::vec3(3.0f, 2.5f, 12.0f),

		0.0f, 0.0f, 180.0f,
		glm::vec3(5.25f, 0.0f, 6.0f));

	SetShaderColor(0.95f, 0.97f, 1.0f, 0.3f);
	m_basicMeshes->DrawHollowCylinderMesh();

}

//adding in pill object
//also updated it so i could duplicate and rotate it without messing up the shape combination


void SceneManager::DrawPill(
	glm::vec3 position,
	float rotateX,
	float rotateY,
	float rotateZ)
{
	//parent transformation that controls the whole pill
	glm::mat4 parent(1.0f);

	parent = glm::translate(parent, position);

	parent = glm::rotate(parent, glm::radians(rotateX),
		glm::vec3(1.0f, 0.0f, 0.0f));

	parent = glm::rotate(parent, glm::radians(rotateY),
		glm::vec3(0.0f, 1.0f, 0.0f));

	parent = glm::rotate(parent, glm::radians(rotateZ),
		glm::vec3(0.0f, 0.0f, 1.0f));

	// draw each component relative to the parent
	auto drawPart = [&](glm::vec3 offset,
		glm::vec3 scale, bool cylinder, glm::vec3 color)
		{
			glm::mat4 model = glm::translate(parent, offset);

			
			if (cylinder)
			{
				model = glm::rotate(model, glm::radians(90.0f),
					glm::vec3(0.0f, 0.0f, 1.0f));
			}

			model = glm::scale(model, scale);

			m_pShaderManager->setMat4Value(g_ModelName, model);

			SetShaderColor(color.r, color.g, color.b, 1.0f);

			if (cylinder)
				m_basicMeshes->DrawCylinderMesh();
			else
				m_basicMeshes->DrawSphereMesh();
		};

	// greenish half
	// cylinder 
	drawPart(
		//position
		glm::vec3(-0.07f, 0.0f, 0.0f),
		//size
		glm::vec3(0.3f, 0.5f, 0.3f),
		true,
		//color
		glm::vec3(0.55f, 0.9f, 0.75f));

	//rounded end
	drawPart(
		//position
		glm::vec3(-0.5f, 0.0f, 0.0f),
		//size
		glm::vec3(0.375f, 0.3f, 0.3f),
		false,
		//color
		glm::vec3(0.55f, 0.9f, 0.75f));

	//blue half
	//cylinder 
	drawPart(
		glm::vec3(0.37f, 0.0f, 0.0f),
		glm::vec3(0.3f, 0.5f, 0.3f),
		true,
		glm::vec3(0.0f, 0.5f, 0.95f));

	//rounded end
	drawPart(
		glm::vec3(0.35f, 0.0f, 0.0f),
		glm::vec3(0.375f, 0.3f, 0.3f),
		false,
		glm::vec3(0.0f, 0.5f, 0.95f));
}












/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	SetShaderLights();
	m_pShaderManager->setBoolValue("bUseLighting", true);

	//default material properties
	m_pShaderManager->setVec3Value(
		"material.ambientColor", 1.0f, 1.0f, 1.0f);

	m_pShaderManager->setFloatValue(
		"material.ambientStrength", 0.3f);

	m_pShaderManager->setVec3Value(
		"material.diffuseColor", 1.0f, 1.0f, 1.0f);

	m_pShaderManager->setVec3Value(
		"material.specularColor", 0.5f, 0.5f, 0.5f);

	m_pShaderManager->setFloatValue(
		"material.shininess", 32.0f);

	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	//pharamcy counter surface 
	scaleXYZ = glm::vec3(20.0f, 1.0f, 20.0f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, -1.35f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("pod-texture");
	SetTextureUVScale(4.0f, 4.0f);

	//pod lighting
	m_pShaderManager->setVec3Value("material.specularColor", 0.25f, 0.25f, 0.25f);
	m_pShaderManager->setFloatValue("material.shininess", 16.0f);

	m_basicMeshes->DrawPlaneMesh();

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh


	//capsules
	// 
	// original pill format
	DrawPill(glm::vec3(0.0f, 0.5f, 3.0f), 0.0f, 0.0f, 0.0f);
	//drawing multiple orientations of the pills
	DrawPill(glm::vec3(-5.0f, 0.5f, 3.0f), 0.0f, 45.0f, 0.0f);
	DrawPill(glm::vec3(-11.5f, -0.7f, 4.5f), 0.0f, 80.0f, 0.0f);
	DrawPill(glm::vec3(-5.0f, 0.5f, 6.0f), 0.0f, 192.0f, 0.0f);
	DrawPill(glm::vec3(0.0f, 0.5f, 9.0f), 90.0f, 0.0f, 45.0f);
	
	
	//spatula
	DrawSpatula(glm::vec3(0.0f, 0.4f, 0.0f));
	
	//tray
	DrawTray();

	//pill bottle
	DrawPillBottle();

	/****************************************************************/
}
